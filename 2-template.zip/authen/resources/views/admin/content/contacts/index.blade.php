@extends('admin.layouts.glance')
@section('title')
    Quản trị contacts
@endsection
@section('content')
    <h1> Quản trị contacts</h1>
@endsection

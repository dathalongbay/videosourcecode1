@extends('admin.layouts.glance')
@section('title')
    Quản trị admins
@endsection
@section('content')
    <h1> Quản trị admins</h1>
@endsection

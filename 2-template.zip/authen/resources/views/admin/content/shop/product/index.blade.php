@extends('admin.layouts.glance')
@section('title')
    Quản trị sản phẩm
@endsection
@section('content')
    <h1> Quản trị sản phẩm</h1>
@endsection

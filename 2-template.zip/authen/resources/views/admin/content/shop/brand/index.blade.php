@extends('admin.layouts.glance')
@section('title')
    Quản trị nhãn hiệu
@endsection
@section('content')
    <h1> Quản trị nhãn hiệu</h1>
@endsection

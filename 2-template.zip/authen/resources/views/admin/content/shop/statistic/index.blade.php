@extends('admin.layouts.glance')
@section('title')
    Thống kê
@endsection
@section('content')
    <h1> Thống kê</h1>
@endsection

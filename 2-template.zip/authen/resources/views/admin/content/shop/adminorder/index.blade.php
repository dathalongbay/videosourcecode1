@extends('admin.layouts.glance')
@section('title')
    Admin đặt hàng
@endsection
@section('content')
    <h1> Admin đặt hàng</h1>
@endsection

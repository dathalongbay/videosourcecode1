<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class ShopCategoryModel extends Model
{
    //
    public $table = 'shop_category';
}

<?php $__env->startSection('title'); ?>
    Cấu hình trang web
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1> Cấu hình trang web</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.glance', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
@extends('admin.layouts.glance')
@section('title')
    Quản trị đánh giá sản phẩm
@endsection
@section('content')
    <h1> Quản trị đánh giá sản phẩm</h1>
@endsection

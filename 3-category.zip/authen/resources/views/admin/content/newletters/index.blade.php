@extends('admin.layouts.glance')
@section('title')
    Quản trị newletters
@endsection
@section('content')
    <h1> Quản trị newletters</h1>
@endsection

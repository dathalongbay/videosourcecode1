<?php $__env->startSection('content'); ?>
    <div id="page-wrapper" style="min-height: 398px; margin-left: 0; margin-bottom: 0">
    <div class="main-page login-page ">
        <h2 class="title1"><?php echo e(__('Login admin')); ?></h2>
        <div class="widget-shadow">
            <div class="login-body">
                <form action="<?php echo e(route('admin.auth.loginAdmin')); ?>" method="post">
                    <?php echo csrf_field(); ?>

                    <input id="email" type="email" class="user <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>


                <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                    <?php endif; ?>

                    <input id="password" type="password" class="lock <?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>


                <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                    <?php endif; ?>

                    <div class="forgot-grid">
                        <label class="checkbox">
                            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            <i></i>Remember me
                        </label>

                        <?php if(Route::has('password.request')): ?>
                            <div class="forgot">
                                <a href="<?php echo e(route('password.request')); ?>">forgot password?</a>
                            </div>
                        <?php endif; ?>
                        <div class="clearfix"> </div>
                    </div>
                    <input type="submit" name="Sign In" value="<?php echo e(__('Login admin')); ?>">
                    <div class="registration">
                        Don't have an account ?
                        <a class="" href="signup.html">
                            Create an account
                        </a>
                    </div>
                </form>
            </div>
        </div>

    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
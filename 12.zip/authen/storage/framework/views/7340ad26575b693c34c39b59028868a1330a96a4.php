<?php $__env->startSection('title'); ?>
    Danh mục nội dung
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1> Danh mục nội dung</h1>

    <div style="margin: 20px 0">
        <a href="<?php echo e(url('admin/content/category/create')); ?>" class="btn btn-success">Thêm danh mục</a>
    </div>
    <div class="tables">
        <div class="table-responsive bs-example widget-shadow">
            <h4>Tổng số : </h4>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Tên</th>
                    <th>Slug</th>
                    <th>Images</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($cat->id); ?></th>
                        <td><?php echo e($cat->name); ?></td>
                        <td><?php echo e($cat->slug); ?></td>
                        <td><?php echo e($cat->images); ?></td>
                        <td>
                            <a href="<?php echo e(url('admin/content/category/'.$cat->id.'/edit')); ?>" class="btn btn-warning">Sửa</a>
                            <a href="<?php echo e(url('admin/content/category/'.$cat->id.'/delete ')); ?>" class="btn btn-danger">Xóa</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($cats->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.glance', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
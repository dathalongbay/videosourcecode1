<?php $__env->startSection('title'); ?>
    Quản trị menu
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1> Quản trị menu</h1>
    <div style="margin: 20px 0">
        <a href="<?php echo e(url('admin/menu/create')); ?>" class="btn btn-success">Thêm menu</a>
    </div>
    <div class="tables">
        <div class="table-responsive bs-example widget-shadow">
            <h4>Tổng số : </h4>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Tên</th>
                    <th>Vị trí</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($menu->id); ?></th>
                        <td><?php echo e($menu->name); ?></td>

                        <td>
                            <?php if(isset($locations[$menu->location])): ?>
                            <?php echo e($locations[$menu->location]); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(url('admin/menu/'.$menu->id.'/edit')); ?>" class="btn btn-warning">Sửa</a>
                            <a href="<?php echo e(url('admin/menu/'.$menu->id.'/delete ')); ?>" class="btn btn-danger">Xóa</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($menus->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.glance', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
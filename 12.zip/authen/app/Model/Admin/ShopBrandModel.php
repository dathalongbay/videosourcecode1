<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class ShopBrandModel extends Model
{
    //
    public $table = 'shop_brands';
}

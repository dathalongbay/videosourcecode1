<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class ConfigModel extends Model
{
    //
    public $table = 'global_settings';
}

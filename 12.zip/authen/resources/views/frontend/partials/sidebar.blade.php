<div class="col-md-4 w3ls_dresses_grid_left">
    <div class="w3ls_dresses_grid_left_grid">
        <h3>Categories</h3>
        <div class="w3ls_dresses_grid_left_grid_sub">
            <div class="ecommerce_dres-type">
                <ul>
                    <li><a href="women.html">Dresses</a></li>
                    <li><a href="women.html">Sarees</a></li>
                    <li><a href="women.html">Shorts &amp; Skirts</a></li>
                    <li><a href="women.html">Jeans</a></li>
                    <li><a href="women.html">Shirts</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="w3ls_dresses_grid_left_grid">
        <h3>Color</h3>
        <div class="w3ls_dresses_grid_left_grid_sub">
            <div class="ecommerce_color">
                <ul>
                    <li><a href="#"><i></i> Red(5)</a></li>
                    <li><a href="#"><i></i> Brown(2)</a></li>
                    <li><a href="#"><i></i> Yellow(3)</a></li>
                    <li><a href="#"><i></i> Violet(6)</a></li>
                    <li><a href="#"><i></i> Orange(2)</a></li>
                    <li><a href="#"><i></i> Blue(1)</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="w3ls_dresses_grid_left_grid">
        <h3>Size</h3>
        <div class="w3ls_dresses_grid_left_grid_sub">
            <div class="ecommerce_color ecommerce_size">
                <ul>
                    <li><a href="#">Medium</a></li>
                    <li><a href="#">Large</a></li>
                    <li><a href="#">Extra Large</a></li>
                    <li><a href="#">Small</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="w3ls_dresses_grid_left_grid">
        <div class="dresses_img_hover">
            <img src="{{ asset('frontend_assets/images') }}/offer.jpg" alt=" " class="img-responsive">
            <div class="dresses_img_hover_pos">
                <h4>Upto<span>40%</span><i>Off</i></h4>
            </div>
        </div>
    </div>
</div>
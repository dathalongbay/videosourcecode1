<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class ShopCategoryModel extends Model
{
    //
    public $table = 'shop_category';
}

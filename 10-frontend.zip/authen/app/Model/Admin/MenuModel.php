<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class MenuModel extends Model
{
    //
    public $table = 'menus';


}

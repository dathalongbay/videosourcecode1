<?php $__env->startSection('title'); ?>
    Danh mục nội dung
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1> Xóa tag <?php echo e($tag->id . ' : ' .$tag->name); ?></h1>

    <div class="row">
        <div class="form-three widget-shadow">
            <form name="tag" action="<?php echo e(url('admin/content/tag/'.$tag->id.'/delete')); ?>" method="post" class="form-horizontal">
                <?php echo csrf_field(); ?>

                <div class="col-sm-offset-2">
                    <button type="submit" class="btn btn-danger">Xóa</button>
                </div>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.glance', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
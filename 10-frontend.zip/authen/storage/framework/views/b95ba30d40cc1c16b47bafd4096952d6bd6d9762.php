<?php $__env->startSection('title'); ?>
    Quản trị khách mua hàng
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1> Quản trị khách mua hàng</h1>

    <div style="margin: 20px 0">
        <a href="<?php echo e(url('admin/shop/customer/create')); ?>" class="btn btn-success">Thêm khách mua hàng</a>
    </div>
    <div class="tables">
        <div class="table-responsive bs-example widget-shadow">
            <h4>Tổng số : </h4>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Tên</th>
                    <th>Email</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($customer->id); ?></th>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td>
                            <a href="<?php echo e(url('admin/shop/customer/'.$customer->id.'/edit')); ?>" class="btn btn-warning">Sửa</a>
                            <a href="<?php echo e(url('admin/shop/customer/'.$customer->id.'/delete ')); ?>" class="btn btn-danger">Xóa</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($customers->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.glance', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
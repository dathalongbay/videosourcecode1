<?php $__env->startSection('title'); ?>
    Quản trị media
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1> Quản trị media</h1>

    <div style="margin-top: 30px">
        <iframe src="http://localhost/lar.tuto/authen/public/laravel-filemanager" style="width: 100%; height: 1000px; overflow: hidden; border: none;"></iframe>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.glance', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
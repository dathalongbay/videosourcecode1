@extends('admin.layouts.glance')
@section('title')
    Quản trị banners
@endsection
@section('content')
    <h1> Quản trị banners</h1>
@endsection

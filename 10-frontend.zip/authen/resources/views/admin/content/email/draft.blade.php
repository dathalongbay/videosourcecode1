@extends('admin.layouts.glance')
@section('title')
    Quản trị draft
@endsection
@section('content')
    <h1> Quản trị draft</h1>
@endsection

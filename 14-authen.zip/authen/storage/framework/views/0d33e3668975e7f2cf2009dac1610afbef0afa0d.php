<?php $__env->startSection('title'); ?>
    Post <?php echo e($post->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="payment">
        <div class="container">
            <h3><?php echo e($post->name); ?></h3>
            <?php echo $post->desc ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>   
<?php echo $__env->make('frontend.layouts.fashion', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class BannerModel extends Model
{
    //
    public $table = 'banners';
}

<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class ContentPostModel extends Model
{
    //
    public $table = 'content_posts';
}

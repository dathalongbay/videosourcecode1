<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class ShopProductModel extends Model
{
    //
    public $table = 'shop_products';
}

<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class ContentTagModel extends Model
{
    //
    public $table = 'content_tags';
}

<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class ContentPostModel extends Model
{
    //
    public $table = 'content_posts';
}

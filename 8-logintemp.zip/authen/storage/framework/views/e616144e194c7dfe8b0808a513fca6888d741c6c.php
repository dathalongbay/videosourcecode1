<?php $__env->startSection('content'); ?>
    <div id="page-wrapper" style="min-height: 428px;margin-left: 0">
        <div class="main-page signup-page">
            <h2 class="title1">SignUp Here</h2>
            <div class="sign-up-row widget-shadow">
                <h5>Personal Information :</h5>
                <form method="POST" action="<?php echo e(route('admin.register.store')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="sign-u">
                        <input id="name" type="text" class="<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>


                    <?php if($errors->has('name')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                        <?php endif; ?>

                        <div class="clearfix"> </div>
                    </div>
                    <div class="sign-u">

                        <input id="email" type="email" class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>


                    <?php if($errors->has('email')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                        <?php endif; ?>
                        <div class="clearfix"> </div>
                    </div>

                    <h6>Login Information :</h6>
                    <div class="sign-u">
                        <input id="password" type="password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                        <?php endif; ?>
                        <div class="clearfix"> </div>
                    </div>
                    <div class="sign-u">
                        <input id="password-confirm" type="password" class="" name="password_confirmation" required>
                    </div>
                    <div class="clearfix"> </div>
                    <div class="sub_home">
                        <input type="submit" value="Submit">
                        <div class="clearfix"> </div>
                    </div>
                    <div class="registration">
                        Already Registered.
                        <a class="" href="<?php echo e(route('admin.auth.login')); ?>">
                            Login
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
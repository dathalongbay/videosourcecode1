@extends('admin.layouts.glance')
@section('title')
    Quản trị email send
@endsection
@section('content')
    <h1> Quản trị email send</h1>
@endsection

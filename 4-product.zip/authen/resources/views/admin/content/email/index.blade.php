@extends('admin.layouts.glance')
@section('title')
    Quản trị email
@endsection
@section('content')
    <h1> Quản trị email</h1>
@endsection

@extends('admin.layouts.glance')
@section('title')
    Quản trị bài viết
@endsection
@section('content')
    <h1> Quản trị bài viết</h1>
@endsection

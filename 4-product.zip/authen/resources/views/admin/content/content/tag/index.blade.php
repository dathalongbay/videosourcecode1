@extends('admin.layouts.glance')
@section('title')
    Quản trị tag
@endsection
@section('content')
    <h1> Quản trị tag</h1>
@endsection

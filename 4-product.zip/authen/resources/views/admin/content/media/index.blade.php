@extends('admin.layouts.glance')
@section('title')
    Quản trị media
@endsection
@section('content')
    <h1> Quản trị media</h1>
@endsection

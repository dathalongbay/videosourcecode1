<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class ShopProductModel extends Model
{
    //
    public $table = 'shop_products';
}

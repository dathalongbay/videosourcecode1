<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class ContentCategoryModel extends Model
{
    //
    public $table = 'content_category';
}

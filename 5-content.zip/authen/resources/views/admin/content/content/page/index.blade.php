@extends('admin.layouts.glance')
@section('title')
    Quản trị trang
@endsection
@section('content')
    <h1> Quản trị trang</h1>
@endsection

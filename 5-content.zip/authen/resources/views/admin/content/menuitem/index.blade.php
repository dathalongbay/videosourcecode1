@extends('admin.layouts.glance')
@section('title')
    Quản trị menu items
@endsection
@section('content')
    <h1> Quản trị menu items</h1>
@endsection

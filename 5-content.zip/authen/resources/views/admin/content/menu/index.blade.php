@extends('admin.layouts.glance')
@section('title')
    Quản trị menu
@endsection
@section('content')
    <h1> Quản trị menu</h1>
@endsection

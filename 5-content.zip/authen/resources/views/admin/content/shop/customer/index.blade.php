@extends('admin.layouts.glance')
@section('title')
    Quản trị khách mua hàng
@endsection
@section('content')
    <h1> Quản trị khách mua hàng</h1>
@endsection

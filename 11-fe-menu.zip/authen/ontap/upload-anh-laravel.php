<?php
/**
 * Upload ảnh
 * Thêm ảnh
 * Xóa ảnh
 */
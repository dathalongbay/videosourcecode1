@extends('admin.layouts.glance')
@section('title')
    Cấu hình trang web
@endsection
@section('content')
    <h1> Cấu hình trang web</h1>
@endsection

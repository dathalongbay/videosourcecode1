@extends('admin.layouts.glance')
@section('title')
    Quản trị đơn hàng
@endsection
@section('content')
    <h1> Quản trị đơn hàng</h1>
@endsection

<?php $__env->startSection('title'); ?>
    Quản trị menu items
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1> Quản trị menu items</h1>
    <div style="margin: 20px 0">
        <a href="<?php echo e(url('admin/menuitems/create')); ?>" class="btn btn-success">Thêm menu item</a>
    </div>
    <div class="tables">
        <div class="table-responsive bs-example widget-shadow">
            <h4>Tổng số : </h4>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Tên</th>
                    <th>Parent</th>
                    <th>Menu</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody>

                <?php $__currentLoopData = $menuitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($item->id); ?></th>
                        <td><?php echo e($item->name); ?></td>
                        <td><?php echo e($item->parent_id); ?></td>
                        <td><?php echo e($item->menu_id); ?></td>
                        <td>
                            <a href="<?php echo e(url('admin/menuitems/'.$item->id.'/edit')); ?>" class="btn btn-warning">Sửa</a>
                            <a href="<?php echo e(url('admin/menuitems/'.$item->id.'/delete ')); ?>" class="btn btn-danger">Xóa</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($menuitems->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.glance', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
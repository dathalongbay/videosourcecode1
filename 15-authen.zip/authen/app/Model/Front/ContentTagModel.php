<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class ContentTagModel extends Model
{
    //
    public $table = 'content_tags';
}

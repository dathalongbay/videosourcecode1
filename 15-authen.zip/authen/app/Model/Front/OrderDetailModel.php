<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class OrderDetailModel extends Model
{
    //
    public $table = 'orders_detail';
}

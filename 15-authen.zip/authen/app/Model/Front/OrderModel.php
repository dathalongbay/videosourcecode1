<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class OrderModel extends Model
{
    //
    public $table = 'orders';
}

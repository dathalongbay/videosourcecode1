<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<!--head-->
<?php echo $__env->make('admin.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--//head-->
<body class="cbp-spmenu-push">
<div class="main-content">
    <!--left-fixed -navigation-->

    <!-- header-starts -->
    <!-- //header-ends -->
    <!-- main content start-->
    <?php echo $__env->yieldContent('content'); ?>


</div>
<!--main js-->
<?php echo $__env->make('admin.partials.main-js', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--//main js-->

</body>
</html>
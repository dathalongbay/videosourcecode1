<?php $__env->startSection('title'); ?>
    Tag nội dung <?php echo e($tag->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <style type="text/css">
        #webmag-custom .post.post-thumb {
            position: static;
        }
    </style>

    <link rel="stylesheet" href="<?php echo e(asset('frontend_assets/webmag/css/style.css')); ?>" type="text/css" media="all" />

    <div id="webmag-custom" style="clear: both">
        <div class="section">
            <!-- container -->
            <div class="container">
                <!-- row -->
                <div class="row">
                    <div class="col-md-12">
                        <div class="row">

                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <!-- post -->
                                <div class="col-md-12">
                                    <div class="post post-row">
                                        <a class="post-img" href="<?php echo e(url('content/post/'.$post->id)); ?>"><img src="<?php echo e(asset($post->images)); ?>" alt=""></a>
                                        <div class="post-body">
                                            <div class="post-meta">
                                                <span class="post-date"><?php echo e($post->created_at); ?></span>
                                            </div>
                                            <h3 class="post-title"><a href="<?php echo e(url('content/post/'.$post->id)); ?>"><?php echo e($post->name); ?></a></h3>
                                            <p><?php echo $post->intro ?></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- /post -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <div class="col-md-12">
                                <div class="section-row">
                                    <?php echo e($posts->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>


                </div>
                <!-- /row -->
            </div>
            <!-- /container -->
        </div>
    </div>

<?php $__env->stopSection(); ?>   
<?php echo $__env->make('frontend.layouts.fashion', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title'); ?>
    Danh mục nội dung
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h1> Sửa newsletter <?php echo e($newsletter->id . ' : ' .$newsletter->name); ?></h1>

    <div class="row">
        <div class="form-three widget-shadow">

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form name="page" action="<?php echo e(url('admin/newsletters/'.$newsletter->id)); ?>" method="post" class="form-horizontal">
                <?php echo csrf_field(); ?>
                
                <div class="form-group">
                    <label for="focusedinput" class="col-sm-2 control-label">email</label>
                    <div class="col-sm-8">
                        <input type="text" name="email" value="<?php echo e($newsletter->email); ?>" class="form-control1" id="focusedinput" placeholder="Default Input">
                    </div>
                </div>
                

                <div class="col-sm-offset-2">
                    <button type="submit" class="btn btn-success">Submit</button>
                </div>
            </form>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.glance', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title'); ?>
    Trang search
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="sub-banner my-banner2">
</div>
<div class="content">
    <div class="container">

        <div class="col-md-12 col-sm-12 women-dresses">



            <?php if($result->count() < 1): ?>
                <h2>No result <?php echo e($result->count()); ?></h2>
            <?php endif; ?>

            <?php $i = 0; ?>
                <div class="women-set1">
            <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                            // 0 . 3 . 6. 9. 12
                    if (($i % 3) == 0 ) {
                        ?>
                        <div class="clearfix"></div>
                </div>
                <div class="women-set<?php echo e($i); ?>">
                        <?php
                    }
                    ?>

                    <?php
                    $images = (isset($product->images) && $product->images) ? json_decode($product->images) : array();
                    ?>

                        <div class="col-md-4 women-grids wp1 animated wow slideInUp" data-wow-delay=".5s">
                            <a href="<?php echo e(url('shop/product/'.$product->id)); ?>"><div class="product-img">

                                    <?php if (count($images)) : ?>
                                    <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <img src="<?php echo e(asset($image)); ?>" alt="" />
                                        <?php break; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>

                                    <div class="p-mask">
                                        <form action="<?php echo url('shop/cart/add') ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="cmd" value="_cart" />
                                            <input type="hidden" name="add" value="1" />
                                            <input type="hidden" name="w3ls1_item" value="<?php echo e($product->id); ?>" />
                                            <input type="hidden" name="amount" value="<?php echo e($product->priceSale); ?>" />
                                            <button type="submit" class="w3ls-cart pw3ls-cart"><i class="fa fa-cart-plus" aria-hidden="true"></i> Add to cart</button>
                                        </form>
                                    </div>
                                </div></a>
                            <i class="fa fa-star yellow-star" aria-hidden="true"></i>
                            <i class="fa fa-star yellow-star" aria-hidden="true"></i>
                            <i class="fa fa-star yellow-star" aria-hidden="true"></i>
                            <i class="fa fa-star yellow-star" aria-hidden="true"></i>
                            <i class="fa fa-star gray-star" aria-hidden="true"></i>
                            <h4><?php echo e($product->name); ?></h4>
                            <h5>VND <?php echo e($product->priceSale); ?></h5>
                        </div>

                    <?php $i++; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="clearfix"></div>
                <?php echo e($result->links()); ?>



        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.fashion', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
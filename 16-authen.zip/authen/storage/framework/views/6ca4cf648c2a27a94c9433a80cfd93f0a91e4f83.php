<?php $__env->startSection('title'); ?>
    Cảm ơn đã đăng ký bản tin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h1>Cảm ơn đã đăng ký bản tin</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.fashion', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
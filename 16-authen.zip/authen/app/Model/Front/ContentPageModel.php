<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class ContentPageModel extends Model
{
    //
    public $table = 'content_pages';
}

<?php

namespace App\Model\Front;

use Illuminate\Database\Eloquent\Model;

class BrandModel extends Model
{
    //
    public $table = 'shop_brands';
}

<?php

namespace App\Model\Admin;

use Illuminate\Database\Eloquent\Model;

class ShopOrderModel extends Model
{
    //
    public $table = 'orders';
}

@extends('frontend.layouts.fashion')
@section('title')
    Cảm ơn đã đăng ký bản tin
@endsection

@section('content')

    <h1>Cảm ơn đã đăng ký bản tin</h1>

@endsection
@extends('frontend.layouts.fashion')
@section('title')
    Thanh toán
@endsection

@section('content')
    <h1>Đặt hàng thành công</h1>
@endsection